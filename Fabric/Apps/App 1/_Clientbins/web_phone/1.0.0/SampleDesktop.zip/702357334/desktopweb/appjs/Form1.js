define("Form1", function() {
    return function(controller) {
        function addWidgetsForm1() {
            this.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0c441de059abb4d = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "FlexContainer0c441de059abb4d",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "94dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "91dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SampleDesktop"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0c441de059abb4d.setDefaultUnit(voltmx.flex.DP);
            var Label0b1c7d58e682840 = new voltmx.ui.Label({
                "id": "Label0b1c7d58e682840",
                "isVisible": true,
                "left": 39,
                "skin": "defLabel",
                "text": "hello",
                "top": 90,
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0c441de059abb4d.add(Label0b1c7d58e682840);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "1366": {
                    "FlexContainer0c441de059abb4d": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {}
            this.add(FlexContainer0c441de059abb4d);
        };
        return [{
            "addWidgets": addWidgetsForm1,
            "enabledForIdleTimeout": false,
            "id": "Form1",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "SampleDesktop"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});